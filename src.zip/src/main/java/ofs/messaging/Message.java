/**
 * This class encapsulates the messages that the producers write
 */
package ofs.messaging;

import java.util.UUID;
import java.io.Serializable;

/**
 * @author Ramanan Natarajan
 *
 */

public class Message implements Serializable {

	private String MessageId = "";
	private int ttl = Constants.MAX_TIME_TO_LIVE_IN_DAYS;
	private Payload payload;
	private boolean isRedundant = true;
	private String producerId = "";
	private int sequenceNo = 0;

	/**
	 * 
	 * @param producerId
	 *            Single argument constructor that takes in a producer id and generates the Message
	 *            object
	 */
	public Message(String producerId) {

		this.producerId = producerId;
		this.MessageId = generateMessageId();

	}

	/**
	 * Two argument constructor takes in a producer id and payload object and creates a Message
	 * 
	 * @param producerId
	 * @param payload
	 */

	public Message(String producerId, Payload payload) {

		this.producerId = producerId;
		this.MessageId = generateMessageId();
		this.payload = payload;

	}

	/**
	 * @return the messageId
	 */
	public String getMessageId() {
		return MessageId;
	}

	/**
	 * @return the payload
	 */
	public Payload getPayload() {
		return payload;
	}

	/**
	 * @return the producerId
	 */
	public String getProducerId() {
		return producerId;
	}

	/**
	 * @return the ttl
	 */
	public int getTtl() {
		return ttl;
	}

	/**
	 * @return the isRedundant
	 */
	public boolean isRedundant() {
		return isRedundant;
	}

	/**
	 * returns a string representation of an UUID object.
	 * 
	 * @return
	 */
	public String generateMessageId() {
		return MessageId = UUID.randomUUID().toString();
	}

	/**
	 * @param messageId
	 *            the messageId to set
	 */
	public void setMessageId(String messageId) {
		MessageId = messageId;
	}

	/**
	 * @param payload
	 *            the payload to set
	 */
	public void setPayload(Payload payload) {
		this.payload = payload;
	}

	/**
	 * @param producerId
	 *            the producerId to set
	 */
	public void setProducerId(String producerId) {
		this.producerId = producerId;
	}

	/**
	 * @param isRedundant
	 *            the isRedundant to set
	 */
	public void setRedundant(boolean isRedundant) {
		this.isRedundant = isRedundant;
	}

	/**
	 * @param ttl
	 *            This is the time to live in Days. takes the value from constant
	 */
	public void setTtl(int ttl) {
		this.ttl = ttl;
	}

	/**
	 * @return the sequenceNo
	 */
	public int getSequenceNo() {
		return sequenceNo;
	}

	/**
	 * @param sequenceNo
	 *            the sequenceNo to set
	 */
	public void setSequenceNo(int sequenceNo) {
		this.sequenceNo = sequenceNo;
	}

}
