/**
 * 
 */
package ofs.messaging;

/**
 * @author ramanann
 *
 */
public class Constants {

	/**
	 * 0 means infinitely .non zero- for that period
	 */
	public static final int MAX_TIME_TO_LIVE_IN_DAYS = 0;

}
