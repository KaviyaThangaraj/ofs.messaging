/**
 * 
 */
package ofs.messaging.Client;

import java.io.IOException;
import java.util.Map;

/**
 * @author ramanann
 *
 */

public interface Channel {

	public com.rabbitmq.client.Channel createChannel();

	/**
	 * @param exchange
	 * @param type
	 *            Exchange is the name of the exchange and type defines one of topic or queues
	 */
	// TODO: to appropriately javadoc this exchange type
	public void exchangeDeclare(String exchange, ExchangeType type);

	/**
	 * @param exchange
	 * @param type
	 * @param durable
	 * @param autoDelete
	 */
	public void exchangeDeclare(String exchange, ExchangeType type, boolean durable,
			boolean autoDelete);

	/**
	 * @param exchange
	 * @param type
	 * @param durable
	 * @param autoDelete
	 * @param internal
	 * @param arguments
	 */
	public void exchangeDeclare(String exchange, ExchangeType type, boolean durable,
			boolean autoDelete, boolean internal, Map<String, Object> arguments);

	// TODO: understand what this mandatory flag means?. rabbit mq doesnt support immediate
	// set default to false;
	public void basicPublish(String exchange, String routingKey, boolean mandatory,
			boolean immediate, byte[] body);

	public void basicPublish(String exchange, String routingKey, boolean mandatory,
			boolean immediate, com.rabbitmq.client.AMQP.BasicProperties props, byte[] body);

	public void basicPublish(String exchange, String routingKey, byte[] body);

	public void close();

}
