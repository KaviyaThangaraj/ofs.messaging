/**
 * 
 */
package ofs.messaging.Client;

/**
 * @author ramanann
 *
 */
public interface MessagingClient {

	public ofs.messaging.Client.Connection Connect();

	public boolean Publish();

	public boolean Consume();
}
