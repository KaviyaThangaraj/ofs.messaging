/**
 * 
 */
package ofs.messaging.Client.Impl;

import ofs.messaging.Client.Connection;
import ofs.messaging.Client.MessagingClient;

/**
 * @author ramanann
 *
 */
public class RabbitMQClient implements MessagingClient {

	public ofs.messaging.Client.Connection Connect() {

		return null;
	}

	public boolean Publish() {

		return false;
	}

	public boolean Consume() {

		return false;
	}

}
