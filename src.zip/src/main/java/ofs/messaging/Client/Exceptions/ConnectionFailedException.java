package ofs.messaging.Client.Exceptions;

public class ConnectionFailedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8081331316651675513L;

	public ConnectionFailedException() {
		super();
	}

	public ConnectionFailedException(String Message) {
		super(Message);

	}

	public ConnectionFailedException(String Message, Throwable cause) {
		super(Message, cause);
	}

	public ConnectionFailedException(Throwable cause) {
		super(cause);
	}

}
