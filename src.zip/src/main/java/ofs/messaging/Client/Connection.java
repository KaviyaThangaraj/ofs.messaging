package ofs.messaging.Client;

public interface Connection {
	public com.rabbitmq.client.Connection connect();

	// public com.rabbitmq.client.Channel createChannel();

}
