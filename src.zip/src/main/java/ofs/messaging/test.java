package ofs.messaging;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import ofs.messaging.Client.Channel;
import ofs.messaging.Client.ExchangeType;
import ofs.messaging.Client.Impl.RabbitMQChannel;
import ofs.messaging.Client.Impl.RabbitMQConnection;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		RabbitMQConnection con = new RabbitMQConnection("localhost", 5673);

		try {

			Channel c = new RabbitMQChannel(con.connect());

			c.createChannel();
			c.exchangeDeclare("exchange 1", ExchangeType.topic);

			long startTime = System.currentTimeMillis();
			// System.out.println();
			for (int i = 0; i < 1000; i++) {
				Payload payload = new Payload();
				payload.setPayLoadFormat(PayloadFormat.BINARY);

				Path path = Paths.get("IMG_0895.MOV");
				byte[] data = null;

				data = Files.readAllBytes(path);
				payload.setbData(data);

				Message msg = new Message("TEST CLIENT 1", payload);
				msg.generateMessageId();

				c.basicPublish("exchange 1", "test", ByteUtil.toByteArray(msg));
			}
			long endTime = System.currentTimeMillis();
			System.out.println((endTime - startTime));
			c.close();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

		}
	}
}
