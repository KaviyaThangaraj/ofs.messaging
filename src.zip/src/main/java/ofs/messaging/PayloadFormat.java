/**
 * 
 */
package ofs.messaging;

/**
 * @author ramanann
 *
 */
public enum PayloadFormat {

	TEXT, BINARY, XMLDOCUMENT;

}
